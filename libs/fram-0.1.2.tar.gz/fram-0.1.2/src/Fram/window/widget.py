import tkinter as tk
import tkinter.ttk as ttk
from Fram.window.protocols import PFrame
from abc import ABC, abstractmethod

class Widget(ABC):
    def __init__(self, class_obj, parent, WidgetConfig):
        self.parent:PFrame = parent
        self.config = WidgetConfig
        self.context =  class_obj(master = self.parent.context, **self.config)

    @abstractmethod
    def pack(self, column:int, row:int):
        ...

class TKWidget(Widget):
    def pack(self, column:int, row:int):
        self.context.grid(column= column, row=row, sticky="nsew")
        return self

    def auto_pack(self, cnf):
        self.context.pack(cnf)
        return self

class VariableAccess:
    variables = []
    def __init__(self):
        ...
    def get_variable(self):
        _tk_list = tk.Variable()
        VariableAccess.variables += [_tk_list]
        return _tk_list
    
    def get_string_variable(self, default = ''):
        _tk_str = tk.StringVar(value = default)
        VariableAccess.variables += [_tk_str]
        return _tk_str

    
    def get_int_variable(self, default = 0):
        _tk_str = tk.IntVar(value = default)
        VariableAccess.variables += [_tk_str]
        return _tk_str

class Label(TKWidget):
    def __init__(self, parent, text, config ={}):
        self.text_var = VariableAccess().get_string_variable(text)
        config.update({"textvariable": self.text_var})
        super().__init__(tk.Label, parent, config)
    
    def set(self, text):
        self.text_var.set(text)
    

class SpinBox(TKWidget):
    def __init__(self, parent, config={}):
        self.spin_var = VariableAccess().get_int_variable()
        config.update({"variable": self.spin_var})
        super().__init__(tk.Spinbox, parent, config)

    def set(self, value):
        self.spin_var.set(value)

    def get(self, value):
        self.spin_var.set(value)

class Entry(TKWidget):
    def __init__(self, parent, config={}):
        self.entry_var = VariableAccess().get_string_variable()
        config.update({"textvariable": self.entry_var})
        super().__init__(tk.Entry, parent, config)

    def get(self):
        return self.entry_var.get()

class Combo(TKWidget):
    def __init__(self, parent, values, config={}):
        self.combo_var = VariableAccess().get_string_variable()
        config.update({"values": values, "textvariable":self.combo_var})
        super().__init__(ttk.Combobox, parent, config)
    
    def get(self):
        return self.combo_var.get()

class Button(TKWidget):
    def __init__(self, parent, text, config={}):
        config.update({"text":text})
        super().__init__(tk.Button, parent, config)

    def trigger(self, callback):
        self.context.configure(command = callback)
        return self

class CheckButton(TKWidget):
    def __init__(self, parent, text, config={}): 
        self.check_var = VariableAccess().get_string_variable()
        config.update({"text":text, "textvariable":self.check_var})
        super().__init__(tk.Checkbutton, parent, config)

    def get(self):
        return self.check_var.get()

    def trigger(self, callback):
        self.context.configure(command = callback)
        return self