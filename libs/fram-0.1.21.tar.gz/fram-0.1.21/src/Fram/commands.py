from abc import ABC, abstractmethod
from typing import Protocol

class PCommand(Protocol):
    def execute(self) -> None:
        ...
    def undo(self) -> None:
        ...

class CommandHistory:
    history:list[PCommand] = []
    
    def push(self, command:PCommand):
        command.execute()
        CommandHistory.history += [command]
    
    def pop(self):
        last_command = CommandHistory.history.pop()
        last_command.undo()


class Command(ABC):
    def __init__(self, app):
        self.app = app
        CommandHistory.push(self)

    @abstractmethod
    def execute(self):
        ...
    
    @abstractmethod
    def undo(self):
        ...