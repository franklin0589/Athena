import tkinter as tk
from Fram.window.protocols import PWindowContext


class WindowConfig:
    def __init__(self, name:str, x:int, y:int, width:int, height:int):
        self.name = name
        self.x = x
        self.y = y
        self.w = width
        self.h = height


class TKWindowContext:
    def __init__(self):
        self.context: tk.Toplevel =  tk.Tk()
    
    def title(self, name:str):
        self.context.title(name)
    
    def size(self, x, y, w, h):
        self.context.geometry(f"{w}x{h}+{x}+{y}")
    
    def run(self):
        self.context.mainloop()


class Window():
    def __init__(self, config:WindowConfig):
        # self.name = name 
        self.config = config
        self.context: PWindowContext = TKWindowContext()
        self.context.title(config.name)
        self.context.size(config.x, config.y, config.w, config.h)

    def run(self):
        self.context.run()

