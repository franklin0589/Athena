import tkinter as tk
from Fram.window.widget import TKWidget

class Cursor:
    def __init__(self):
        self.x = 0
        self.y = 0
    def set_pos(self, x:int, y:int):
        self.x = x
        self.y = y
    
    def move_pos(self, dx:int, dy:int):
        self.x += dx
        self.y += dy
    def get(self):
        return (self.x, self.y)

class Canvas(TKWidget):
    def __init__(self, parent, config = {}):
        self.cursor = Cursor()
        self.layers = ["Layer0"]
        self.cursor_layer = 0
        super().__init__(tk.Canvas, parent, config)
        
    def size_update(self):
        self.width = self.context.winfo_reqheight()
        self.height = self.context.winfo_reqwidth()

    def add_layer(self):
        self.layers += [f"Layer{len(self.layers)}"]
    
    def move_cursor(self, dx, dy, layer = -1):
        self.cursor.move_pos(dx, dy)
        self.cursor_layer = layer if layer < 0 else self.cursor_layer

    def clear_canvas(self):
        self.context.delete("all")




class CanvasObject:
    def __init__(self, obj, index, pos, layer, config = {}):
        self.context = obj.context
        config.update({"tag": layer})

        self.draw(index, pos, config)

    def draw(self, index, pos, config) :
        objects = ["create_arc","create_bitmap","create_line","create_oval","create_polygon","create_rectangle","create_text","create_image"]
        self.id = getattr(self.context, objects[index])(*pos, **config)

    def configure(self, options):
        self.context.itemconfig(self.id, **options)
 
    def set_to_pos(self, x, y):
        self.context.coords(self.id, x, y)

    def scale(self, xS, yS):
        self.context.scale(self.id, 0, 0, xS, yS)

    def get(self):
        return self.id

    def remove(self, index):
        self.context.delete(index)

class Arc(CanvasObject):
    def __init__(self, canvas, layer, x1, y1, x2, y2, config = {}):
        super().__init__(canvas, 0, [x1, y1, x2, y2], layer, config)

class Bitmap(CanvasObject):
    def __init__(self, canvas, layer, x, y, config = {}):
        self.bitmap = ""
        super().__init__(canvas, 1, [x, y], layer, config)

class Line(CanvasObject):
    def __init__(self, canvas, layer, x, y, x2, y2, config = {}):
        super().__init__(canvas, 2, [x, y, x2, y2], layer, config)

class Oval(CanvasObject):
    def __init__(self, canvas, layer, x, y, x2, y2, config = {}):
        super().__init__(canvas, 3, [x, y, x2, y2], layer, config)

class Polygon(CanvasObject):
    def __init__(self, canvas, layer, points, config = {}):
        super().__init__(canvas, 4, points, layer, config)

class Rectangle(CanvasObject):
    def __init__(self, canvas, layer, x,y,l,w, config = {}):
        super().__init__(canvas, 5, [x,y, x+w, y+l], layer, config)

class Text(CanvasObject):
    def __init__(self, canvas, layer, x,y , config = {}):
        super().__init__(canvas, 6, [x,y], layer, config)

class Image(CanvasObject):
    def __init__(self, canvas, layer, x,y, config = {}):
        super().__init__(canvas, 7, [x,y], layer, config)
