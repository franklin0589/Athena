from abc import ABC, abstractmethod
from Fram.window.protocols import PFrame
import tkinter as tk

class BaseFrame(ABC):
    def __init__(self, parent, WidgetConfig):
        self.parent:PFrame = parent
        self.rows = 0
        self.columns = 0
        self.config = WidgetConfig


    @abstractmethod
    def pack(self, column:int, row:int):
        ...
    
    @abstractmethod
    def crack_horizontal(self, weight): 
        self.columns += 1
        
    @abstractmethod
    def crack_vertical(self, weight): 
        self.rows += 1
        
    def build_grid(self, column_weights:list[int], row_weights:list[int]):
        for _r in row_weights:
            self.crack_vertical(_r)
        for _c in column_weights:
            self.crack_horizontal(_c)

class TKFrame(BaseFrame):
    def __init__(self, parent, WidgetConfig):
        super().__init__(parent, WidgetConfig)
        self.context = tk.Frame(parent.context, self.config)
        self.build()

    def build(self):
        ...

    def fill(self):
        if isinstance(self.parent.context, tk.Tk):
            self.context.pack(fill="both", expand=True)
        else:
            self.parent.crack_vertical(1)
            self.parent.crack_horizontal(1)
            self.pack(0, 0)

    def pack(self, column:int, row:int):
        self.context.grid(row = row, column = column, sticky="nsew")
        
    def crack_horizontal(self, weight):
        self.context.grid_columnconfigure(self.columns, weight = weight)
        super().crack_horizontal(weight)

    def crack_vertical(self, weight):
        self.context.grid_rowconfigure(self.rows, weight = weight)
        super().crack_vertical(weight)

class HorizontalContainer(TKFrame):
    def __init__(self, parent, WidgetConfig):
        super().__init__(parent, WidgetConfig)
        self.crack_vertical(1)
        
    def add_frame(self, frame, weight = 1):
        self.crack_horizontal(weight)
        frame.pack(self.columns-1, 0)

class VerticalContainer(TKFrame):
    def __init__(self, parent, WidgetConfig):
        super().__init__(parent, WidgetConfig)
        self.crack_horizontal(1)
        
    def add_frame(self, frame, weight = 1):
        self.crack_vertical(weight)
        frame.pack(0, self.rows-1)
    