import os
import sys
from configparser import ConfigParser
from pathlib import Path

def _get_rpath(relative_path:str):
    # If running as a PyInstaller EXE
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        # Running in normal Python
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)

def _make_folder(fdl_path:str):
    if not Path(fdl_path).exists():
        os.mkdir(fdl_path)

class Configuration:
    def __init__(self, name:str):
        self.name = name
        self.config_folder_path = _get_rpath("config/")
        self.config_abs_path = _get_rpath(f"config/{name}.ini")
        _make_folder(self.config_folder_path)
        if Path(self.config_abs_path).exists():
            self.config = self.compile_config()
        else:
            self.config = self.assemble_config() 

    def compile_config(self):
        cp = ConfigParser()
        cp.read(self.app_path)
        return cp
            
    def assemble_config(self):
        cp = ConfigParser()
        cp["DEFAULT"] = self.build() 
        with open(self.app_path, "w") as configfile:
            cp.write(configfile)
        return cp

    def get_config(self):
        return self.config["DEFAULT"]

    def build(self) -> dict:
        raise NotImplementedError()