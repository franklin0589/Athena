import os 
from typing import Optional

class ProjectFileManager:
    def __init__(self, project_directory:str):
        self.project_dir = project_directory

    def save(self):
        ...
    
    def load(self):
        ...