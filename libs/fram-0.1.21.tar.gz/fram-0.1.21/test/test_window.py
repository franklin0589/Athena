import Fram as f


class Colored_Frame(f.window.TKFrame):
    def __init__(self, parent, color):
        config = {"background": color}
        super().__init__(parent, config)

    def build(self):
        ...

class Recursive_Horizontal_Frame(f.window.TKFrame):
    def __init__(self, parent, color):
        config = {"background": color}
        super().__init__(parent, config)

    def build(self):
        test = f.window.HorizontalContainer(self, {})
        test.fill()
        inner_left  = Colored_Frame(test, "yellow")
        inner_right = Colored_Frame(test, "magenta")
        test.add_frame(inner_left)
        test.add_frame(inner_right)

class NewVerticalFrame(f.window.TKFrame):
    def __init__(self, parent, color):
        config = {"background": color}
        super().__init__(parent, config)
    
    def build(self):
        test = f.window.VerticalContainer(self, {})
        test.fill()
        inner_top = Colored_Frame(test, "cyan")
        inner_middle = ItemFrame(test, {"background":"red"})
        inner_bottom = Colored_Frame(test, "blue")
        test.add_frame(inner_top)
        test.add_frame(inner_middle, 5)
        test.add_frame(inner_bottom)

class CanvasFrame(f.window.TKFrame):
    def build(self):
        c = f.window.Canvas(self, {})
        c.auto_pack({"expand":True, "fill":"both"})
        c.size_update()
        for i in range(20):
            f.window.Line(c, "Layer0", 0, 50+10*i, c.width, 50+10*i)

class ItemFrame(f.window.TKFrame):
    def build(self):
        f.window.Label(self, "Hello World").auto_pack({"anchor":"nw"})
        
        change = f.window.Label(self, "How Are You Doing").auto_pack({"anchor":"nw"})
        f.window.Entry(self).auto_pack({"anchor":"nw"})
        f.window.Combo(self, ["Tom", "Jane", "SecondTom"]).auto_pack({"anchor":"nw"})
        b = f.window.Button(self, "Hello World").auto_pack({"anchor":"nw"})
        b.trigger(lambda: change.set("Hello World"))
        c = f.window.CheckButton(self, "Good?").auto_pack({"anchor":"nw"})
        c.trigger(lambda: c.get() )

class New_Window(f.window.Window):
    def __init__(self):
        config = f.window.WindowConfig("Test", 10, 10, 1000, 800)
        super().__init__(config)
        self.build()
        self.run()
        
    def build(self):
        main = f.window.HorizontalContainer(self.context, {"background": "red"})
        main.fill()
        
        left = NewVerticalFrame(main, "blue")
        # right = Recursive_Horizontal_Frame(main, "green")
        right = CanvasFrame(main, {})
        main.add_frame(left)
        main.add_frame(right)
        
        
        ...
        

def test_window():
    New_Window()
    ...