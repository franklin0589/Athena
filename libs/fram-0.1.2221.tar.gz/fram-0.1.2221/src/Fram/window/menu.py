import tkinter as tk
class MenuItem:
    def __init__(self, menu_bar, name):
        self.menu = tk.Menu(menu_bar, tearoff=0)
        self.name  = name
        menu_bar.add_cascade(label=name, menu=self.menu)

    def add_command(self, label:str, command):
        self.menu_item.add_command(label=label, command=command)
    def add_separator_bar(self):
        self.menu_item.add_separator()

class MenuBar:
    def __init__(self, root):
        self.context = tk.Menu(root)
        root.config(menu=self.context)

    def add_tab(self, tab_name) -> MenuItem:
        return MenuItem(self.context) 